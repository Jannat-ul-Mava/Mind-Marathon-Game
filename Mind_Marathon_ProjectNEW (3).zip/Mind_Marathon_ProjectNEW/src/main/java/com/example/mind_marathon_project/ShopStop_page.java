package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class ShopStop_page extends Application {

    @Override
    public void start(Stage stage6) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage6);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");
        root.setTop(customTitleBar);

        Button backButton = new Button();

        ImageView arrowImageView = loadImage("/com/example/mind_marathon_project/arrow.png");
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(35);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: #1b548d; -fx-border-color: #1b548d;");

        VBox headerBox = new VBox(backButton);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setPadding(new Insets(0, 0, 10, 0));

        HBox titleBar = new HBox();
        titleBar.setStyle("-fx-background-color: #f1f5f6;-fx-background-radius: 20px;-fx-border-radius: 20px;-fx-border-color:#ff7bac;-fx-border-width: 2px;-fx-padding: 5,0,5,0");
        titleBar.setSpacing(10);
        titleBar.setAlignment(Pos.CENTER);
        titleBar.setMaxWidth(300);
        titleBar.setMaxHeight(90);

        Label headerLabel = new Label("  Shop Stop");
        headerLabel.setStyle("-fx-text-fill: #b78fd6;-fx-font-weight: bold;-fx-font-family: 'Comic Sans MS';-fx-font-size: 24px");
        headerLabel.setAlignment(Pos.CENTER);

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);

        ImageView money = loadImage("/com/example/mind_marathon_project/money.png");
        money.setFitWidth(50);
        money.setFitHeight(50);
        titleBar.getChildren().addAll(headerLabel, money);

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #1b548d; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 0px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(500);

        // Create a Label for displaying purchase success message
        Label purchaseMessage = new Label();
        purchaseMessage.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
        purchaseMessage.setAlignment(Pos.CENTER);

        HBox hbox1 = new HBox();
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setSpacing(20);
        hbox1.setStyle("-fx-background-color: #1b548d;");

        ImageView hintlogo = loadImage("/com/example/mind_marathon_project/hint_image.png");
        hintlogo.setFitHeight(110);
        hintlogo.setFitWidth(150);

        Button buyButtonhint = new Button("BUY");
        buyButtonhint.setStyle("-fx-background-color: #fffcf6;-fx-border-color:#b78fd6;-fx-border-width: 3px;-fx-border-radius: 18px;-fx-text-fill: #3d3939;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 10");
        addButtonEffects(buyButtonhint, "/com/example/mind_marathon_project/main_button.mp3");
        buyButtonhint.setOnAction(e -> {
            // Show a success message for Hint purchase
            purchaseMessage.setText("You have successfully purchased a Hint!");
        });

        hbox1.getChildren().addAll(hintlogo, buyButtonhint);

        HBox hbox2 = new HBox();
        hbox2.setAlignment(Pos.CENTER);
        hbox2.setSpacing(20);
        hbox2.setStyle("-fx-background-color: #1b548d;");

        ImageView lifelogo = loadImage("/com/example/mind_marathon_project/life_image.png");
        lifelogo.setFitHeight(90);
        lifelogo.setFitWidth(150);

        Button buyButtonlife = new Button("BUY");
        buyButtonlife.setStyle("-fx-background-color: #fffcf6;-fx-border-color:#b78fd6;-fx-border-width: 3px;-fx-border-radius: 18px;-fx-text-fill: #3d3939;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 10");
        addButtonEffects(buyButtonlife, "/com/example/mind_marathon_project/main_button.mp3");
        buyButtonlife.setOnAction(e -> {
            // Show a success message for Life purchase
            purchaseMessage.setText("You have successfully purchased a Life!");
            purchaseMessage.setStyle("-fx-text-fill: White; -fx-font-weight: bold; -fx-font-size: 20px;");
        });

        hbox2.getChildren().addAll(lifelogo, buyButtonlife);

        VBox vbox = new VBox(1, headerBox, titleBar, hbox1, hbox2, purchaseMessage);
        vbox.setStyle("-fx-alignment: center; -fx-padding: 1; -fx-background-color: #1b548d;");
        vbox.setAlignment(Pos.CENTER);

        cardPane.getChildren().addAll(vbox);

        root.setCenter(cardPane);

        backButton.setOnAction(e -> {
            try {
                new Menu_page().start(new Stage());
                stage6.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(root, 800, 600);
        stage6.initStyle(StageStyle.UNDECORATED);
        stage6.setMaximized(true);
        stage6.setScene(scene);
        stage6.show();
    }

    // Helper method to load images
    private ImageView loadImage(String path) {
        try {
            return new ImageView(new Image(getClass().getResourceAsStream(path)));
        } catch (NullPointerException e) {
            System.out.println("Image not found: " + path);
            return new ImageView();
        }
    }

    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
