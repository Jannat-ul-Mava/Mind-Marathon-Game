package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.*;

public class Login_page extends Application {

    @Override
    public void start(Stage stage2) {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage2);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");
        root.setTop(customTitleBar);

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #fffcf6;" +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 20px;");
        vbox.setMaxWidth(600);
        vbox.setMaxHeight(500);

        ImageView login;
        try {
            login = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/login.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/login.png", e);
        }
        login.setFitWidth(170);
        login.setFitHeight(90);

        StackPane formContainer = new StackPane();
        formContainer.setAlignment(Pos.CENTER);

        ImageView loginImage;
        try {
            loginImage = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/log_pic.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/log_pic.png", e);
        }
        loginImage.setFitWidth(350);
        loginImage.setFitHeight(350);

        VBox formFields = new VBox(40);
        formFields.setAlignment(Pos.CENTER);
        formFields.setPadding(new Insets(10));

        TextField nameField = new TextField();
        nameField.setMaxWidth(150);
        nameField.setMinHeight(40);
        nameField.setPromptText("\tEnter your name");
        nameField.setStyle("-fx-background-color:  #fffcf6;-fx-background-radius: 20px;-fx-border-width: 2px;" +
                "-fx-border-radius: 20px;-fx-prompt-text-fill: #675c6e;-fx-border-color: #b78fd6;" +
                "-fx-text-fill: #3c6ca8;-fx-font-weight: bold;-fx-font-family: Calibri;" +
                "-fx-padding: 5px;-fx-font-size:14px; ");

        Slider ageSlider = new Slider();
        ageSlider.setMin(1);
        ageSlider.setMax(60);
        ageSlider.setPrefWidth(80);
        ageSlider.setStyle(
                "-fx-control-inner-background: #79ccab ;" +
                        "-fx-background-color: #3c6ca8;" +
                        "-fx-border-color: transparent;" +
                        "-fx-base: #b78fd6;"
        );

        Label ageLabel = new Label("0");
        ageLabel.setStyle("-fx-text-fill: #ffffff; -fx-font-size: 14px;-fx-font-weight: bold");
        ageSlider.valueProperty().addListener((obs, oldVal, newVal) -> ageLabel.setText(String.valueOf(newVal.intValue())));
        Label age1 =new Label("Age:");
        age1.setStyle("-fx-text-fill: #ffffff;-fx-font-size: 14px;-fx-font-weight: bold");
        HBox ageContainer = new HBox(10,age1 , ageSlider, ageLabel);
        ageContainer.setAlignment(Pos.CENTER);

        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(150);
        passwordField.setMinHeight(40);
        passwordField.setPromptText("  Enter your password");
        passwordField.setStyle("-fx-background-color: #fffcf6;-fx-prompt-text-fill: #675c6e;" +
                "-fx-border-color: #b78fd6; " +
                "-fx-border-radius: 20px;-fx-border-width: 2px;" +
                "-fx-background-radius: 20px; " +
                "-fx-padding: 5px; " +
                "-fx-font-size: 14px;-fx-text-fill: #3c6ca8;-fx-font-weight: bold;-fx-font-family: Calibri;");

        formFields.getChildren().addAll(nameField, ageContainer, passwordField);
        formContainer.getChildren().addAll(loginImage, formFields);

        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: #fdf58e;-fx-border-color:#f59eb7;" +
                "-fx-border-width: 2px;-fx-border-radius: 20px;-fx-text-fill: #3c6ca8;" +
                "-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;" +
                "-fx-font-size: 18px;-fx-padding: 10 20");
        addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");

//        okButton.setOnAction(actionEvent -> {
//            Stage currentStage = (Stage) okButton.getScene().getWindow();
//            String name = nameField.getText();
//            String age = ageLabel.getText();  // or use ageSlider.getValue() if you prefer
//            String password = passwordField.getText();
//
//            if (name.isEmpty() || password.isEmpty()) {
//                showAlert("Error", "Name and Password cannot be empty!");
//                return;
//            }
//
//            // Store user data
//            //   UserInfo.storeUserData(name, age, password);
//
//            try {
//                new Login_page2().start(new Stage());
//                currentStage.close();
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
//
//            String filepath = "user_data.txt";
//            File file = new File("User_data.txt");
//            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true))) {
//                writer.write("Name: " + name + "\n");
//                writer.write("Age: " + age + "\n");
//                writer.write("Password: " + password + "\n\n");
//                showAlert("Success", "Your login has been stored successfully!");
//                try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
//                    String storedData = reader.lines().reduce("", (prev, curr) -> prev + curr + "\n");
//                    //showAlert("Stored Data", storedData);
//
//                } catch (IOException e) {
//                    e.getMessage();
//                }} catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//
//        });
        okButton.setOnAction(e -> {
            String name = nameField.getText();
            String password = passwordField.getText();
            if (name.isEmpty() || password.isEmpty()) {
                System.out.println("Please fill in both fields.");
                return;
            }


            try (BufferedWriter writer = new BufferedWriter(new FileWriter("user_data.txt", true))) {
                writer.write("Name: " + name + "\n");
                writer.write("Password: " + password + "\n");


                writer.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }


            try {
                new Login_page2().start(new Stage());
                stage2.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });



        vbox.getChildren().addAll(login, formContainer, okButton);
        root.setCenter(vbox);

        Scene scene = new Scene(root, 800, 600);
        stage2.initStyle(StageStyle.UNDECORATED);
        stage2.setMaximized(true);
        stage2.setScene(scene);
        stage2.show();


    }

    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}