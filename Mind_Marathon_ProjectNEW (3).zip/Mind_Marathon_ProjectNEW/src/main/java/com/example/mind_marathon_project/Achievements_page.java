package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;

public class Achievements_page extends Application {

    private int score = 0;
    private ProgressBar progressBar;
    private Label scoreLabel;
    private ImageView medal100, medal500, medal1000;

    private boolean isMedal100Locked = true;
    private boolean isMedal500Locked = true;
    private boolean isMedal1000Locked = true;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage7) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage7);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #1b548d; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 20px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(500);

        HBox titleBar = new HBox();
        titleBar.setAlignment(Pos.CENTER);
        titleBar.setStyle("-fx-background-color: #ffffff;-fx-background-radius: 20px;-fx-border-radius: 20px;-fx-border-color:#ff7bac;-fx-border-width: 2px;-fx-padding: 5,0,5,0");
        titleBar.setSpacing(10);
        titleBar.setMaxWidth(300);
        titleBar.setMaxHeight(90);
        Label headerLabel = new Label("Achievements");
        headerLabel.setStyle("-fx-text-fill: #1b548d;-fx-font-weight: bold;-fx-font-family: 'Comic Sans MS';-fx-font-size: 24px");
        headerLabel.setAlignment(Pos.CENTER);

        ImageView star;
        try{
            star=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/star.png").toExternalForm()));
        }
        catch(NullPointerException e){
            throw e;
        }
        star.setFitWidth(50);
        star.setFitHeight(50);
        titleBar.getChildren().addAll(headerLabel, star);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        spacer.setPrefHeight(50);
        Region spacer2 = new Region();
        VBox.setVgrow(spacer2, Priority.ALWAYS);
        spacer2.setPrefHeight(30);
        Region spacer3 = new Region();
        VBox.setVgrow(spacer3, Priority.ALWAYS);
        spacer3.setPrefHeight(10);

        Button backButton = new Button();


        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(40);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: #1b548d; -fx-border-color: #1b548d;");
        backButton.setOnAction(e -> goBackToMenu());

        VBox headerBox = new VBox(backButton);
        headerBox.setAlignment(Pos.CENTER_LEFT);// Add some spacing after the label for better layout
        headerBox.setPadding(new Insets(0, 0, 10, 0));

        ImageView medal;
        try{
            medal=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/medal_pic.png").toExternalForm()));
        }
        catch(NullPointerException e){
            throw e;
        }
        medal.setFitHeight(40);
        medal.setFitWidth(40);
        progressBar = new ProgressBar(0);
        progressBar.setPrefWidth(300);
        progressBar.setStyle( "-fx-accent: #ffdd51; " +     // Yellow fill color
                "-fx-control-inner-background: #ffffff; " +  // Transparent background
                "-fx-background-radius: 20; " +  // Rounded corners
                "-fx-padding: 5; " +             // Add padding
                "-fx-border-radius: 20; " +      // Rounded border
                "-fx-border-color: #ffde59;");
        scoreLabel = new Label("Score: 0");
        scoreLabel.setFont(new Font("Comic Sans MS", 20));
        scoreLabel.setStyle("-fx-text-fill: white;-fx-font-weight: bold");

        try {
            medal100 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/lock.png").toExternalForm()));
            medal500 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/lock.png").toExternalForm()));
            medal1000 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/lock.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        medal100.setFitWidth(80);
        medal100.setFitHeight(80);
        medal500.setFitWidth(80);
        medal500.setFitHeight(82);
        medal1000.setFitWidth(82);
        medal1000.setFitHeight(84);

        Label medalLabel100 = new Label("Problem-Solver");
        Label medalLabel500 = new Label("Skilled Analyst");
        Label medalLabel1000 = new Label("Sage of Wisdom");
        medalLabel100.setStyle("-fx-text-fill: #f1f5f6;-fx-font-weight: bold;-fx-font-size: 9px;");
        medalLabel500.setStyle("-fx-text-fill: #f1f5f6;-fx-font-weight: bold;-fx-font-size: 9px");
        medalLabel1000.setStyle("-fx-text-fill: #f1f5f6;-fx-font-weight: bold;-fx-font-size: 9px");

        VBox medalBox100 = new VBox(medal100, medalLabel100);
        VBox medalBox500 = new VBox(medal500, medalLabel500);
        VBox medalBox1000 = new VBox(medal1000, medalLabel1000);

        medalBox100.setAlignment(Pos.CENTER);
        medalBox500.setAlignment(Pos.CENTER);
        medalBox1000.setAlignment(Pos.CENTER);

// Set spacing between the medal image and the label
        medalBox100.setSpacing(10);
        medalBox500.setSpacing(10);
        medalBox1000.setSpacing(10);

        HBox medalRow = new HBox(20, medalBox100, medalBox500, medalBox1000);
        medalRow.setAlignment(Pos.CENTER);
        medalRow.setSpacing(50);

        cardPane.getChildren().addAll( headerBox,titleBar,spacer,medal,progressBar, scoreLabel,spacer2, medalRow,spacer3);
        cardPane.setAlignment(Pos.CENTER);

        root.setCenter(cardPane);
        backButton.setOnAction(e->{

            try {
                new Menu_page().start(new Stage());
                stage7.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }

        });

        Scene scene = new Scene(root, 800, 600);
        stage7.initStyle(StageStyle.UNDECORATED);
        stage7.setScene(scene);
        stage7.setMaximized(true);
        stage7.show();
        updateScore(500);


    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        // Play sound effect
        // AudioClip clickSound = new AudioClip(getClass().getResource(soundFile).toExternalForm());

        // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });

        // Play sound on click
        //    button.setOnMouseClicked(e -> clickSound.play());
    }

    public void updateScore(int gameResult) {
        // Increment score based on the game result
        score += gameResult;

        // Ensure score does not exceed 1000
        if (score > 1000) {
            score = 1000;
        }

        // Update progress bar and medals
        progressBar.setProgress((double) score / 1000);
        animateProgressBar((double) score / 1000);

        scoreLabel.setText("Score: " + score);

        // Unlock medals based on the score
        if (score >= 100 && isMedal100Locked) {
            medal100.setImage(new Image(getClass().getResource("/com/example/mind_marathon_project/100_score.png").toExternalForm()));
            isMedal100Locked = false;
            animateUnlock(medal100);
        }
        if (score >= 500 && isMedal500Locked) {
            medal500.setImage(new Image(getClass().getResource("/com/example/mind_marathon_project/500_score.png").toExternalForm()));
            isMedal500Locked = false;
            animateUnlock(medal500);
        }
        if (score >= 1000 && isMedal1000Locked) {
            medal1000.setImage(new Image(getClass().getResource("/com/example/mind_marathon_project/1000_score.png").toExternalForm()));
            isMedal1000Locked = false;
            animateUnlock(medal1000);
        }
    }

    private void animateUnlock(ImageView medal) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(500), medal);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.2);
        scaleTransition.setToY(1.2);
        scaleTransition.setAutoReverse(true);
        scaleTransition.setCycleCount(2);
        scaleTransition.play();
    }

    private void animateProgressBar(double targetProgress) {
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(500), new KeyValue(progressBar.progressProperty(), targetProgress))
        );
        timeline.play();
    }
    private void goBackToMenu() {
        System.out.println("Back to Menu");
    }
}
