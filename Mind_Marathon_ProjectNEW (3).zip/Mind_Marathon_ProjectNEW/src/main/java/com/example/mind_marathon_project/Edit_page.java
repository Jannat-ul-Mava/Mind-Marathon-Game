package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Edit_page extends Application {
    @Override
    public void start(Stage stage9) {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage9);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);

        Button backButton = new Button();
        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        arrowImageView.setFitHeight(30);
        arrowImageView.setFitWidth(30);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_RIGHT);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        backButton.setOnAction(e -> goBackToMenu());

        Label headerLabel = new Label("Edit Information");
        headerLabel.setStyle("-fx-background-radius:20px;-fx-background-size: 20px;-fx-background-color: #fff4f4;-fx-border-color: #ff7bac;-fx-border-radius: 20px;-fx-border-width: 2;-fx-font-size: 24px; -fx-text-fill: #1b548d;-fx-font-family:'Comic Sans MS' ;-fx-font-weight: bold;-fx-padding: 10,10,10,10;");
        headerLabel.setAlignment(Pos.TOP_CENTER);

        HBox headerBox1 = new HBox(headerLabel);
        headerBox1.setAlignment(Pos.TOP_CENTER);
        headerBox1.setSpacing(10);

        VBox headerBox = new VBox(backButton);
        headerBox.setAlignment(Pos.CENTER_LEFT);// Add some spacing after the label for better layout
        headerBox.setPadding(new Insets(0, 0, 10, 0));  // Space between arrow and label
        // TextFields for input
        VBox fields=new VBox();
        fields.setSpacing(30);
        fields.setAlignment(Pos.CENTER);
        TextField nameField = new TextField("XYz"); // Default value as seen in the image
        nameField.setMaxWidth(200);
        nameField.setStyle("-fx-background-color: #fcfcfc;-fx-background-radius: 10px;-fx-border-width: 2;-fx-border-color: #ff7bac ;-fx-border-radius: 10px; -fx-text-fill: #4a4a4a;-fx-font-family:'Comic Sans MS';-fx-padding: 10,5,10,5 ;");

        TextField ageField = new TextField("Age"); // Default value as seen in the image
        ageField.setMaxWidth(200);
        ageField.setStyle("-fx-background-color: #ffffff;-fx-background-radius: 10px;-fx-border-width: 2;-fx-border-color: #ff7bac ; -fx-border-radius: 10px; -fx-text-fill: #4a4a4a;-fx-font-family:'Comic Sans MS' ;-fx-padding: 10,5,10,5 ;");

        TextField passwordField= new TextField("123"); // Default value as seen in the image
        passwordField.setMaxWidth(200);
        passwordField.setStyle("-fx-background-color: #fcfcfc;-fx-background-radius: 10px;-fx-border-width: 2;-fx-border-color: #ff7bac ; -fx-border-radius: 10px; -fx-text-fill: #4a4a4a;-fx-font-family:'Comic Sans MS' ;-fx-padding: 10,5,10,5 ;");
        fields.getChildren().addAll(nameField, ageField, passwordField);
        // OK Button
        Button okButton = new Button("  OK  ");
        okButton.setStyle("-fx-background-radius:20px;-fx-background-size: 100px;-fx-background-color: #ffde59;-fx-border-color: #ff7bac;-fx-border-radius: 20px;-fx-border-width: 2;-fx-font-size: 14px; -fx-text-fill: #3d3939;-fx-font-family:'Comic Sans MS' ;-fx-font-weight: bold;-fx-padding: 10,10,10,10;");
        okButton.setOnAction(e -> handleOkButton(nameField.getText(), ageField.getText(),passwordField.getText()));
        try {
            addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }

        VBox cardPane = new VBox(40,headerBox,headerBox1,fields, okButton);
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #1b548d; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 20px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(500);

        root.setCenter(cardPane);
        backButton.setOnAction(e->{
            try {
                new Menu_page().start(new Stage());
                stage9.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });



        okButton.setOnAction(e -> {
            String name = nameField.getText();
            String password= passwordField.getText();
            String age = ageField.getText();

            if (name.isEmpty() || password.isEmpty() || age.isEmpty()) {
                System.out.println("Name, password, or age is empty");
                return;
            }

            boolean isAuthenticated = false;
            StringBuilder updatedFileContent = new StringBuilder();

            try (Scanner scanner = new Scanner(new File("user_data.txt"))) {
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    boolean isUserUpdated = false;


                    if (line.startsWith("Name: ")) {
                        String storedName = line.substring(6).trim();
                        String storedPassword = "";
                        String storedAge = "";


                        while (scanner.hasNextLine()) {
                            line = scanner.nextLine();
                            if (line.startsWith("Password: ")) {
                                storedPassword = line.substring(10).trim();
                            } else if (line.startsWith("Age: ")) {
                                storedAge = line.substring(5).trim();
                            }


                            if (!storedPassword.isEmpty() && !storedAge.isEmpty()) {
                                break;
                            }
                        }


                        if (name.equals(storedName) && password.equals(storedPassword)) {
                            isAuthenticated = true;
                            updatedFileContent.append("Name: ").append(name).append("\n"); // Keep the name unchanged
                            updatedFileContent.append("Password: ").append(password).append("\n"); // Keep the password unchanged
                            updatedFileContent.append("Age: ").append(age).append("\n"); // Update the age
                            isUserUpdated = true;
                        }
                    }


                    if (!isUserUpdated) {
                        updatedFileContent.append(line).append("\n");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                return;
            }


            if (isAuthenticated) {
                try (FileWriter writer = new FileWriter("user_data.txt")) {
                    writer.write(updatedFileContent.toString());
                    System.out.println("Successfully logged in and updated details");

                    // Show an alert that the login details have been updated successfully
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Update Successful");
                    alert.setHeaderText("Login Details Updated");
                    alert.setContentText("Your login details, have been successfully updated.");
                    alert.showAndWait();


                    try {
                        new Menu_page().start(new Stage());
                        stage9.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            } else {
                System.out.println("Failed to login");
            }
        });



        Scene scene = new Scene(root, 800, 600);
        stage9.initStyle(StageStyle.UNDECORATED);
        stage9.setMaximized(true);
        stage9.setScene(scene);
        stage9.show();
    }
    private void handleOkButton(String name, String age, String otherInfo) {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Other Info: " + otherInfo);
        // Here you can add additional logic to process the input
    }

    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }
    private void goBackToMenu() {
        System.out.println("Back to Menu");
    }
}
