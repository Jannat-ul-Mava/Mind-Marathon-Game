package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu_page extends Application {

    private ImageView profileImageView;
    private List<Image> preloadedImages;


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage5) throws Exception {
        preloadedImages = loadPreloadedImages();
        CustomTitleBar customTitleBar = new CustomTitleBar(stage5);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #f7f2e8; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ffde59; " +
                "-fx-padding: 20px;");
        cardPane.setMaxWidth(650);
        cardPane.setMaxHeight(500);

        //VBox center=new VBox();
        //center.setAlignment(Pos.CENTER);
        Circle borderCircle = new Circle(75); // Radius of the circle
        borderCircle.setStyle("-fx-fill: rgba(255,228,122,0.71); -fx-stroke: #5eb090; -fx-stroke-width: 7;-fx-background-radius: 70"); // Background color and border

        // Profile image circle
        profileImageView = new ImageView();
       // profileImageView.setFitWidth(200);
      //  profileImageView.setFitHeight(200);
     //   profileImageView.setStyle("-fx-background-color: rgba(255,228,122,0.66);-fx-border-color: #5eb090;-fx-border-width: 9;-fx-background-radius: 50;-fx-border-radius: 50;");
      //  profileImageView.setClip(new Circle(70,70,70)); // Circle clipping
        StackPane profileImageStack = new StackPane();
        profileImageStack.getChildren().addAll(borderCircle, profileImageView);
        profileImageStack.setAlignment(Pos.CENTER);
        // "Choose Image" button
        Button chooseImageButton = new Button("Choose image");
        chooseImageButton.setStyle("-fx-background-color: #fdf58e; -fx-font-size: 14px; -fx-border-color: #ffc107;-fx-padding: 3px;");
        //chooseImageButton.setOnAction(e -> chooseImage(stage5));
        addButtonEffects(chooseImageButton,"/com/example/mind_marathon_project/click_sound.mp3");
        chooseImageButton.setOnAction(e -> openImageSelectionDialog(stage5));


        // Name and Age labels
        Label nameLabel = new Label("JM");
        nameLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #000;");

        Label ageLabel = new Label("19");
        ageLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #000;");

        HBox labels = new HBox(20,nameLabel, ageLabel);
        labels.setAlignment(Pos.CENTER);
        VBox profileSection = new VBox(10, profileImageStack, labels);
        profileSection.setAlignment(Pos.CENTER);
        HBox ImageStack=new HBox();
        ImageStack.setSpacing(40);
        ImageStack.getChildren().addAll(profileSection,chooseImageButton);
        ImageStack.setAlignment(Pos.CENTER);

        // Top-left and top-right buttons
        Button Button1 = new Button();
        ImageView imageView1 ;
        try {
            imageView1 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/award_png.png").toExternalForm()));
        }catch(NullPointerException e){
            throw e;
        }
        imageView1.setFitWidth(30);
        imageView1.setFitHeight(30);
        Button1.setGraphic(imageView1);
        Button1.setStyle("-fx-background-color: #3c6ca8;-fx-border-color: #ffe47a;-fx-border-width: 3px;-fx-background-radius: 10px;-fx-border-radius:7px;-fx-padding:4;-fx-background-size: 2");

        Button Button2 = new Button();
        ImageView imageView ;
        try {
            imageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/edit_png.png").toExternalForm()));
        }catch(NullPointerException e){
            throw e;
        }
        imageView.setFitWidth(30);
        imageView.setFitHeight(30);
        Button2.setGraphic(imageView);
        Button2.setStyle("-fx-background-color: #3c6ca8;-fx-border-color: #ffe47a;-fx-border-width: 3px;-fx-background-radius: 10px;-fx-border-radius:7px;-fx-padding:4;-fx-background-size: 2");

        addButtonEffects(Button2,"/com/example/mind_marathon_project/click_sound.mp3");
        addButtonEffects(Button1,"/com/example/mind_marathon_project/click_sound.mp3");

        // Bottom-left and bottom-right buttons
        Button Button3 = new Button();
        ImageView imageView3 ;
        try {
            imageView3 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/info_png.png").toExternalForm()));
        }catch(NullPointerException e){
            throw e;
        }
        imageView3.setFitWidth(30);
        imageView3.setFitHeight(30);
        Button3.setGraphic(imageView3);
        Button3.setStyle("-fx-background-color:#3c6ca8;-fx-border-color: #ffe47a;-fx-border-width: 3px;-fx-background-radius: 10px;-fx-border-radius:7px;-fx-padding:4;-fx-background-size: 2");

        Button Button4 = new Button();
        ImageView imageView4 ;
        try {
            imageView4 = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/shop_png.png").toExternalForm()));
        }catch(NullPointerException e){
            throw e;
        }
        imageView4.setFitWidth(30);
        imageView4.setFitHeight(30);
        Button4.setGraphic(imageView4);
        Button4.setStyle("-fx-background-color: #3c6ca8;-fx-border-color: #ffe47a;-fx-border-width: 3px;-fx-background-radius: 10px;-fx-border-radius:7px;-fx-padding:4;-fx-background-size: 2");

        VBox sideButtons = new VBox(10, Button1, Button2, Button3, Button4);
        sideButtons.setAlignment(Pos.TOP_RIGHT);
        addButtonEffects(Button3,"/com/example/mind_marathon_project/shop_png.png");
        addButtonEffects(Button4,"/com/example/mind_marathon_project/info_png.png");
      //  bottomButtons.maxHeight(100);
       // bottomButtons.maxWidth(200);

        // Play and Exit buttons
        Button playButton = new Button("\t    Play\t\t  ");
        playButton.setStyle("-fx-background-color: #ffe47a; -fx-background-radius: 10px;-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #000;-fx-padding: 10;");
        playButton.setOnAction(e -> System.out.println("Play  clicked"));
        addButtonEffects(playButton,"/com/example/mind_marathon_project/click_sound.mp3");
         Button exitButton = new Button("  \t     Exit       \t ");
        exitButton.setStyle("-fx-background-color: #ffe47a;  -fx-background-radius: 10px;-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #000;-fx-padding: 10;");
        addButtonEffects(exitButton,"/com/example/mind_marathon_project/click_sound.mp3");

        VBox bottomBox = new VBox(playButton, exitButton);
        bottomBox.setStyle("-fx-background-color: #3c6ca8;-fx-background-radius: 20px;-fx-border-color: #439576;-fx-border-radius: 20px;-fx-border-width: 2;-fx-padding: 20,20,20,20");
        bottomBox.setAlignment(Pos.CENTER);
        bottomBox.setMaxWidth(350);
        bottomBox.setSpacing(10);

        HBox centerBox = new HBox(10, sideButtons);
        centerBox.setSpacing(250);
        centerBox.setAlignment(Pos.CENTER_LEFT);

        HBox rightBox = new HBox(10,centerBox,ImageStack);
        rightBox.setSpacing(100);

        cardPane.getChildren().addAll(rightBox, bottomBox);


        root.setCenter(cardPane);
        playButton.setOnAction(e->{
            if(playButton.isHover()){
                try {
                    new Interest_page().start(new Stage());
                    stage5.close();
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        exitButton.setOnAction(e->{
            if (exitButton.isHover()) {
                try {
                    new exit_page().start(new Stage());
                    stage5.close();
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }


//                Alert exitAlert = new Alert(Alert.AlertType.CONFIRMATION);
//                exitAlert.setTitle("Exit Confirmation");
//
//                exitAlert.setHeaderText(null);
//                exitAlert.setContentText("Do you really want to exit?");
//
//
//
//                exitAlert.showAndWait().ifPresent(response -> {
//                    if (response == ButtonType.OK) {
//
//                        System.exit(0);
//                    } else {
//
//                        exitAlert.close();
//                    }
                //});
            } });
        Button1.setOnAction(e->{
            if(Button1.isHover()){}
            try {
                new Achievements_page().start(new Stage());
                stage5.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Button2.setOnAction(e->{
            if(Button2.isHover()){}
            try {
                new Edit_page().start(new Stage());
                stage5.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Button3.setOnAction(e->{
            if(Button3.isHover()){}
            try {
                new info_page().start(new Stage());
                stage5.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Button4.setOnAction(e->{
            if(Button4.isHover()){}
            try {
                new ShopStop_page().start(new Stage());
                stage5.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });


        Scene scene = new Scene(root, 800, 600);
        stage5.initStyle(StageStyle.UNDECORATED);
    //    stage5.setFullScreen(true);
        stage5.setMaximized(true);
        stage5.setScene(scene);
        stage5.show();

    }


    private void chooseImageFromFile(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Profile Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            try {
                Image profileImage = new Image(new FileInputStream(file));
                profileImageView.setFitWidth(150); // Diameter of the circle
                profileImageView.setFitHeight(150);
                profileImageView.setPreserveRatio(false);// Maintain aspect ratio
                profileImageView.setClip(new Circle(75, 75, 75));
                profileImageView.setImage(profileImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void openImageSelectionDialog(Stage stage) {

    VBox dialogContent = new VBox(10);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: #1b548d; -fx-border-color: #5eb090; -fx-border-width: 2;");
        dialogContent.setAlignment(Pos.BASELINE_CENTER);

    Label instructions = new Label("Select an avatar:");
        instructions.setStyle("-fx-font-size: 16px;-fx-text-fill: #ffffff; -fx-font-weight: bold;");

    HBox preloadedImagesBox = new HBox(10);
        preloadedImagesBox.setAlignment(Pos.CENTER);
        for (Image image : preloadedImages) {
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(60);
        imageView.setFitHeight(60);
            StackPane imageContainer = new StackPane(imageView);
            imageContainer.setStyle("-fx-padding: 5; -fx-border-radius: 10; -fx-background-radius: 10;-fx-background-color: #fff4f4;-fx-border-color:#439576 ");

            imageView.setOnMouseClicked(e -> {
                profileImageView.setImage(image);
                animateImageSelection(imageContainer);
                imageContainer.setStyle("-fx-background-color: #fff99f; -fx-border-radius: 10; -fx-background-radius: 10;"); // Yellow background
            });
        preloadedImagesBox.getChildren().add(imageContainer);
    }

    Button chooseFromFileButton = new Button("Choose from computer");
        chooseFromFileButton.setStyle("-fx-background-color: #ffde59; -fx-font-size: 14px;");
        chooseFromFileButton.setOnAction(e -> chooseImageFromFile(stage));
        addButtonEffects(chooseFromFileButton,"/com/example/mind_marathon_project/click_sound.mp3");
        dialogContent.getChildren().addAll(instructions, preloadedImagesBox, chooseFromFileButton);


    Stage dialog = new Stage();
        dialog.initOwner(stage);
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setScene(new Scene(dialogContent));
        dialog.show();
}
    private void animateImageSelection(StackPane imageContainer) {
        // Scale transition on image selection
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), imageContainer);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.2);
        scaleTransition.setToY(1.2);
        scaleTransition.setAutoReverse(true);
        scaleTransition.play();

        // Highlight the selected image with a border
        imageContainer.setStyle("-fx-border-color: #3c6ca8; -fx-border-width: 2; -fx-border-radius: 10; -fx-background-radius: 10;");
    }

    private List<Image> loadPreloadedImages() {
        List<Image> images = new ArrayList<>();
        try {
            images.add(new Image(getClass().getResource("/com/example/mind_marathon_project/avatar1.png").toExternalForm()));
            images.add(new Image(getClass().getResource("/com/example/mind_marathon_project/avatar2.png").toExternalForm()));
            images.add(new Image(getClass().getResource("/com/example/mind_marathon_project/avatar3.png").toExternalForm()));
            images.add(new Image(getClass().getResource("/com/example/mind_marathon_project/avatar4.png").toExternalForm()));
            images.add(new Image(getClass().getResource("/com/example/mind_marathon_project/avatar5.png").toExternalForm()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return images;
    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

    // Play sound effect
    // AudioClip clickSound = new AudioClip(getClass().getResource(soundFile).toExternalForm());

    // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
        scaleTransition.stop();
        button.setScaleX(1.0);
        button.setScaleY(1.0);
    });

    // Play sound on click
    //    button.setOnMouseClicked(e -> clickSound.play());
}
}
