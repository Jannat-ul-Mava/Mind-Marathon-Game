package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;


public class Result_page extends Application {

    public void start(Stage stage2) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage2);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fdeaea;");
        root.setTop(customTitleBar);

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #fdeaea;" +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ffb9e7; " +
                "-fx-padding: 20px;");
        vbox.setMaxWidth(400);
        vbox.setMaxHeight(500);

        ImageView login;
        try {
            login = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/score_pic.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/score_pic.png", e);
        }
        login.setFitWidth(170);
        login.setFitHeight(90);

        StackPane formContainer = new StackPane();
        formContainer.setAlignment(Pos.CENTER);

        ImageView Result_ackgroud;
        try {
            Result_ackgroud = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/result_ackgroud.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/result_ackgroud.png", e);
        }
        Result_ackgroud.setFitWidth(350);
        Result_ackgroud.setFitHeight(350);

        ImageView picture;
        try {
            picture = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/result_ackgroud.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/result_ackgroud.png", e);
        }
        picture.setFitWidth(350);
        picture.setFitHeight(350);

        VBox formFields = new VBox(40);
        formFields.setAlignment(Pos.CENTER);
        formFields.setPadding(new Insets(10));





        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: #fff4f4;-fx-border-color:#FF7BACFF;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-text-fill: #ff7bac;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 20");
        try {
            addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }
        okButton.setOnAction(e -> System.out.println("Name: " ));

        vbox.getChildren().addAll(login,formContainer,okButton);
        root.setCenter(vbox);

        Scene scene = new Scene(root,1000,650);
        stage2.initStyle(StageStyle.UNDECORATED);
        stage2.setScene(scene);
        stage2.show();
    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }
    public static void main(String[] args) {
        launch();
    }
}

