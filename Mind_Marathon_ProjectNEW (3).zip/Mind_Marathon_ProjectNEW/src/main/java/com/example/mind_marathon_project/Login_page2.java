package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class Login_page2 extends Application {

    public void start(Stage stage3) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage3);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");
        root.setTop(customTitleBar);

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #fffcf6;" +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 20px;");
        vbox.setMaxWidth(600);
        vbox.setMaxHeight(500);

        ImageView login;
        try {
            login = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/logi.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/logi.png", e);
        }
        login.setFitWidth(170);
        login.setFitHeight(90);

        StackPane formContainer = new StackPane();
        formContainer.setAlignment(Pos.CENTER);

        ImageView login_image;
        try {
            login_image = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/log_pic.png")));
        } catch (NullPointerException e) {
            throw   e;    }
        login_image.setFitWidth(350);
        login_image.setFitHeight(350);

        VBox formFields = new VBox(40);
        formFields.setAlignment(Pos.CENTER);
        formFields.setPadding(new Insets(10));

        TextField nameField = new TextField();
        nameField.setMaxWidth(150);
        nameField.setMinHeight(40);
        nameField.setPromptText("\tEnter your name");
        nameField.setStyle("-fx-background-color:  #fffcf6;-fx-background-radius: 20px;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-prompt-text-fill: #675c6e;-fx-border-color: #b78fd6;-fx-text-fill: #3c6ca8;-fx-font-weight: bold;-fx-font-family: Calibri;-fx-padding: 5px;-fx-font-size:14px; ");

        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(150);
        passwordField.setMinHeight(40);
        passwordField.setPromptText("  Enter your password");
        passwordField.setStyle("-fx-background-color: #fffcf6;-fx-prompt-text-fill: #675c6e;" +
                "-fx-border-color: #b78fd6; " +
                "-fx-border-radius: 20px;-fx-border-width: 2px;" +
                "-fx-background-radius: 20px; " +
                "-fx-padding: 5px; " +
                "-fx-font-size: 14px;-fx-text-fill: #3c6ca8;-fx-font-weight: bold;-fx-font-family: Calibri;");

        // Add form fields to the container
        formFields.getChildren().addAll(nameField,passwordField);
        formContainer.getChildren().addAll(login_image, formFields);


        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: #fdf58e;-fx-border-color:#f59eb7;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-text-fill: #3c6ca8;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 20");
        try {
            addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }



//        okButton.setOnAction(e -> {
//            Stage currentSatge = (Stage)okButton.getScene().getWindow();
//            String name = nameField.getText();
//            String password = passwordField.getText();
//
//            if (name.isEmpty() || password.isEmpty()) {
//                System.out.println("Name and password are empty");
//                return;
//            }
//
//            boolean isAuthenticated = false;
//
//            try (Scanner scanner = new Scanner(new File("user_data.txt"))) {
//                while (scanner.hasNextLine()) {
//                    String line = scanner.nextLine();
//                    if (line.startsWith("Name: ")) {
//                        String storedName = line.substring(6).trim();
//                        String storedPassword = "";
//
//                        while (scanner.hasNextLine()) {
//                            line = scanner.nextLine();
//                            if (line.startsWith("Password: ")) {
//                                storedPassword = line.substring(10).trim();
//                                break;
//                            }
//                        }
//
//                        if (name.equals(storedName) && password.equals(storedPassword)) {
//                            isAuthenticated = true;
//                            break;
//                        }
//                    }
//                }
//            } catch (IOException ex) {
//                System.out.println("Failed to login");
//                return;
//            }
//
//            if (isAuthenticated) {
//                System.out.println("Successfully logged in");
//                try {
//
//                    new Menu_page().start(new Stage());
//
//                    currentSatge.close();  // Close the login stage
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                }
//            } else {
//                System.out.println("Failed to login");
//            }
//        });
        okButton.setOnAction(e -> {
            String name = nameField.getText();
            String password = passwordField.getText();

            if (name.isEmpty() || password.isEmpty()) {
                System.out.println("Name and password are empty");
                return;
            }

            boolean isAuthenticated = false;

            try (Scanner scanner = new Scanner(new File("user_data.txt"))) {
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("Name: ")) {
                        String storedName = line.substring(6).trim();
                        String storedPassword = "";

                        while (scanner.hasNextLine()) {
                            line = scanner.nextLine();
                            if (line.startsWith("Password: ")) {
                                storedPassword = line.substring(10).trim();
                                break;
                            }
                        }

                        if (name.equals(storedName) && password.equals(storedPassword)) {
                            isAuthenticated = true;
                            break;
                        }
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                return;
            }

            if (isAuthenticated) {
                System.out.println("Successfully logged in");
                try {
                    new Menu_page().start(new Stage());
                    stage3.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                System.out.println("Failed to login");
            }
        });



        vbox.getChildren().addAll(login,formContainer,okButton);
        root.setCenter(vbox);


        Scene scene = new Scene(root,800,600);
        stage3.initStyle(StageStyle.UNDECORATED);
        stage3.setMaximized(true);
        stage3.setScene(scene);
        stage3.show();

    }


    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });



    }
    public static void main(String[] args) {
        launch();
    }
}