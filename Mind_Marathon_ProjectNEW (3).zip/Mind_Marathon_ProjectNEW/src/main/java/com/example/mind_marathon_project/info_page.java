package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;


public class info_page extends Application {
    @Override
    public void start(Stage stage8) {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage8);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");
        root.setTop(customTitleBar);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #1b548d; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 20px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(500);

        Button backButton = new Button();

        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(40);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        backButton.setOnAction(e -> goBackToMenu());

        VBox headerBox = new VBox(backButton);
        headerBox.setAlignment(Pos.CENTER_LEFT);// Add some spacing after the label for better layout
        headerBox.setPadding(new Insets(0, 0, 0, 0));

        Label title= new Label("Info Bank");
        title.setAlignment(Pos.CENTER);
        title.setStyle("-fx-text-fill: white;-fx-font-size: 30px;-fx-font-family: 'Comic Sans MS';-fx-font-weight: bold;-fx-padding: 20");


        ImageView letterBox;
        try{
           letterBox = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/background_pic.png")));
        }
        catch(NullPointerException e){
            throw e;
        }
        letterBox.setFitHeight(350);
        letterBox.setFitWidth(300);

        cardPane.getChildren().addAll(headerBox,title,letterBox);
        root.setCenter(cardPane);
        backButton.setOnAction(e ->{
            try {
                new Menu_page().start(new Stage());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
            stage8.close();
        });
        Scene scene = new Scene(root, 800, 600);
        stage8.initStyle(StageStyle.UNDECORATED);
        stage8.centerOnScreen();
        stage8.setMaximized(true);
        stage8.setScene(scene);
        stage8.show();

    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        // Play sound effect
        // AudioClip clickSound = new AudioClip(getClass().getResource(soundFile).toExternalForm());

        // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });

        // Play sound on click
        //    button.setOnMouseClicked(e -> clickSound.play());
    }
    private void goBackToMenu() {
        System.out.println("Back to Menu");
    }
}
